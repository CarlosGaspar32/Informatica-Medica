function [] = Changecolor_White(app)
    app.DatosgeneralesTab.BackgroundColor = [0.94,0.94,0.94];
end

